import torch
import torch.nn.functional as F

def calculate_uncertainty(sem_seg_logits):
    top2_scores, _ = torch.topk(sem_seg_logits, k=2, dim=1)
    return (top2_scores[:, 1] - top2_scores[:, 0])

def point_sample(input, point_coords, **kwargs):
    add_dim = False
    if point_coords.dim() == 3:
        add_dim = True
        point_coords = point_coords.unsqueeze(2)
    output = F.grid_sample(input, 2.0 * point_coords - 1.0, **kwargs)
    if add_dim:
        output = output.squeeze(3)
    return output

def sample_uncertain_points(coarse_logits, num_points, oversample_factor, importance_sample_ratio):
    assert oversample_factor >= 1
    assert 0 <= importance_sample_ratio and importance_sample_ratio <= 1

    if importance_sample_ratio > 1e-3:
        num_batches = coarse_logits.shape[0]
        num_sampled = int(num_points * oversample_factor)
        num_uncertain_points = int(importance_sample_ratio * num_points)
        num_random_points = num_points - num_uncertain_points

        oversampled_point_coords = torch.rand(num_batches, num_sampled, 2, device=coarse_logits.device)
        oversampled_point_logits = point_sample(coarse_logits, oversampled_point_coords, align_corners=False)
        point_uncertainties = calculate_uncertainty(oversampled_point_logits)

        _, top_indices = torch.topk(point_uncertainties, k=num_uncertain_points, dim=1)
        uncertain_point_coords = torch.stack([oversampled_point_coords[i, j] for i, j in enumerate(top_indices)])

        random_point_coords = torch.rand(num_batches, num_random_points, 2, device=coarse_logits.device)
    
        # point_coords = torch.cat([all_resampled_point_coords, random_point_coords], dim=1)
        point_coords = torch.cat([uncertain_point_coords, random_point_coords], dim=1)
    else:
        num_batches = coarse_logits.shape[0]
        point_coords = torch.rand(num_batches, num_points, 2, device=coarse_logits.device)
    return point_coords


def sample_edge_points(dmap, num_points, oversample_factor, importance_sample_ratio):
    assert oversample_factor >= 1
    assert 0 <= importance_sample_ratio and importance_sample_ratio <= 1

    if importance_sample_ratio > 1e-3:
        num_batches = dmap.shape[0]
        num_sampled = int(num_points * oversample_factor)
        num_uncertain_points = int(importance_sample_ratio * num_points)
        num_random_points = num_points - num_uncertain_points

        oversampled_point_coords = torch.rand(num_batches, num_sampled, 2, device=dmap.device)
        oversampled_point_weights = point_sample(dmap, oversampled_point_coords, align_corners=False).squeeze(1)
        # point_uncertainties = calculate_uncertainty(oversampled_point_logits)
        _, top_indices = torch.topk(oversampled_point_weights, k=num_uncertain_points, dim=1)
        uncertain_point_coords = torch.stack([oversampled_point_coords[i, j] for i, j in enumerate(top_indices)])

        random_point_coords = torch.rand(num_batches, num_random_points, 2, device=dmap.device)
    
        # point_coords = torch.cat([all_resampled_point_coords, random_point_coords], dim=1)
        point_coords = torch.cat([uncertain_point_coords, random_point_coords], dim=1)
    else:
        num_batches = dmap.shape[0]
        point_coords = torch.rand(num_batches, num_points, 2, device=dmap.device)
    return point_coords


def point_sample_on_grid(input_, point_coords):
    _, _, H, W = input_.shape
    size = torch.tensor([H, W], device=input_.device).view(1, 1, 2)
    pt_coords = torch.floor(point_coords * size).long()

    output = torch.stack([x[:, coord[:, 0], coord[:, 1]] for x, coord in zip(input_, pt_coords)], dim=0)
    return output

def sample_uncertain_points_on_grid(coarse_logits, num_points, oversample_factor, importance_sample_ratio):
    assert oversample_factor >= 1
    assert 0 <= importance_sample_ratio and importance_sample_ratio <= 1

    if importance_sample_ratio > 1e-3:
        num_batches, _, H, W = coarse_logits.shape
        num_sampled = int(num_points * oversample_factor)
        num_uncertain_points = int(importance_sample_ratio * num_points)
        num_random_points = num_points - num_uncertain_points

        oversampled_point_coords = torch.rand(num_batches, num_sampled, 2, device=coarse_logits.device)

        oversampled_point_logits = point_sample_on_grid(coarse_logits, oversampled_point_coords)
        

        point_uncertainties = calculate_uncertainty(oversampled_point_logits)

        _, top_indices = torch.topk(point_uncertainties, k=num_uncertain_points, dim=1)
        uncertain_point_coords = torch.stack([oversampled_point_coords[i, j] for i, j in enumerate(top_indices)])

        random_point_coords = torch.rand(num_batches, num_random_points, 2, device=coarse_logits.device)

        point_coords = torch.cat([uncertain_point_coords, random_point_coords], dim=1)
    else:
        num_batches, _, H, W = coarse_logits.shape
        point_coords = torch.rand(num_batches, num_points, 2, device=coarse_logits.device)
    return point_coords


