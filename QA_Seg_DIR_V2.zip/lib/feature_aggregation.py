import torch.nn.functional as F
import torch

def feature_unfold(feat):
	B, C, H, W = feat.shape

	unfolded_1 = F.unfold(feat, kernel_size=3, dilation=1, stride=1, padding=1)
	unfolded_1 = unfolded_1.view(B, C * 3 * 3, H, W)

	unfolded_3 = F.unfold(feat, kernel_size=3, dilation=2, stride=1, padding=2)
	unfolded_3 = unfolded_3.view(B, C * 3 * 3, H, W)
	cond = lambda x: ((x - 4) % 9 != 0)
	unfolded_3 = torch.stack([unfolded_3[:, i] for i in filter(cond, range(C * 9))], dim=1)

	unfolded = torch.cat([unfolded_1, unfolded_3], dim=1)
	return unfolded