from torch import nn
from lib.models.blocks import ResEnsembleConvBlock, ResEnsembleUpBlock


def init_weights_he_normal(neg_slope=1e-2):
    def init(m):
        if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
            m.weight = nn.init.kaiming_normal_(m.weight, a=neg_slope)
            if m.bias is not None:
                m.bias = nn.init.constant_(m.bias, 0)
    return init

class DeepEnsembleUNet(nn.Module):
    def __init__(self, n_channels, n_classes, norm, nonlin, init="he_uniform", dropout=0.):
        super().__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes

        self.first_encoder_conv = ResEnsembleConvBlock(n_channels[0], n_channels[1], norm, nonlin, False, dropout=dropout) 

        self.encoder_blocks = nn.ModuleList([
            ResEnsembleConvBlock(n_channels[i], n_channels[i + 1], norm, nonlin, True, dropout=dropout) 
            for i in range(1, len(n_channels) - 1)
            ])

        self.decoder_blocks = nn.ModuleList([
            ResEnsembleUpBlock(n_channels[i], n_channels[i - 1], norm, nonlin, dropout) 
            for i in reversed(range(2, len(n_channels)))
            ])

        self.last_decoder_conv = ResEnsembleConvBlock(n_channels[1], n_channels[1], norm, nonlin, False, dropout=dropout)

        self.segment_head = nn.Conv2d(n_channels[1], n_classes, kernel_size=1, bias=False)

        if init == "he_uniform": 
            pass # pytorch conv default initialization
        elif init == "he_normal":
            self.apply(init_weights_he_normal())

    def _predict2(self, x):
        x = self.first_encoder_conv(x)


        for encoder_block in self.encoder_blocks[:-1]:
            x = encoder_block(x)
            
        for decoder_block in self.decoder_blocks[1:]:
            x, _ = decoder_block(x)
    
        x = self.last_decoder_conv(x)
        return x

    def _predict1(self, x):
        x = self.first_encoder_conv(x)


        for encoder_block in self.encoder_blocks:
            x = encoder_block(x)
            
        for i, decoder_block in enumerate(self.decoder_blocks):
            x, _ = decoder_block(x)
    
        x = self.last_decoder_conv(x)
        return x
    
    def predict(self, x):
        # out1 = self._predict1(x)
        x = self._predict2(x)
        # x = out1 + out2

        x = self.segment_head(x)
        return x, None


    def forward(self, x):
        x = self.first_encoder_conv(x)

        encoder_features = [x]
        for encoder_block in self.encoder_blocks:
            x = encoder_block(x)
            encoder_features.append(x)

        decoder_features = []
        for i, decoder_block in enumerate(self.decoder_blocks):
            x, decoded_feature = decoder_block(x + encoder_features[-(i + 1)])
            decoder_features.append(decoded_feature)

        x = self.last_decoder_conv(x + encoder_features[0])
        decoder_features.append(x)

        output_logits = self.segment_head(x)
        return output_logits, decoder_features, encoder_features[-1]
