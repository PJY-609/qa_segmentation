from torch import nn
import torch
from lib.models.blocks import Dense



class MLP(nn.Module):
    def __init__(self, n_channels, dropout=0.):
        super().__init__()
        self.n_channels = n_channels

        hidden_layers = [Dense(in_channels, out_channels, "lrelu", dropout) for in_channels, out_channels in zip(n_channels[:-1], n_channels[1:])]
        self.hidden_layers = nn.Sequential(*hidden_layers)

    def forward(self, x):
        x = self.hidden_layers(x)

        return x

class PointMLP(nn.Module):
    def __init__(self, n_channels):
        super().__init__()

        self.adaption_layer1 = Dense(n_channels + 2, 1022, "lrelu", 0.)
        self.adaption_layer2 = Dense(1024, 510, "lrelu", 0.)
        self.adaption_layer3 = Dense(512, 256, "lrelu", 0.)

        self.mlp = MLP([256, 2])

    def forward(self, x, position_encoding):
        x = self.adaption_layer1(torch.cat([x, position_encoding], dim=1))
        x = self.adaption_layer2(torch.cat([x, position_encoding], dim=1))
        x = self.adaption_layer3(torch.cat([x, position_encoding], dim=1))
        x = self.mlp(x)
        return x